'use strict';

const uuid = require('uuid').v4;
const dynamoose = require('dynamoose');
const PeopleModel = require('./people.schema.js');

exports.handler = async (event, id) => {
  try {
    // const parse = JSON.parse(event);
    // const {name, phone} = parse.body;
    // console.log('PARSE---------', parse);
    // console.log('NAME------', name);
    // console.log('PHONE----------', phone);

    console.log('EVENT-----', event);

    const id = event.queryStringParameters && event.queryStringParameters.id;

    const list = await PeopleModel.query('id').eq(id).exec();
    let data = list[0];
    console.log('DATA1----------', data);


    data.name = event.body.name;
    data.phone = event.body.phone;
    data.save();

    console.log('DATA1------', data);

    return {
      statusCode: 200,
      body: JSON.stringify(data)
    }
  } catch (e) {
    return {
      statusCode: 500,
      response: e.message
    }
  }
}